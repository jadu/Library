<?php
require_once 'JaduConstants.php';
$contentWidgetTitle = '%TITLE%' === '%TITLE' . '%' ? '' : '%TITLE%';
$inContent = '%INCONTENT%' === '%INCONTENT' . '%' ? '' : '%INCONTENT%';
$outContent = '%OUTCONTENT%' === '%OUTCONTENT' . '%' ? '' : '%OUTCONTENT%';

if (!defined('PHOTON_ENABLED') || !PHOTON_ENABLED) {
    $isSignedIn = \Jadu\Service\User::getInstance()->isSessionLoggedIn();
} else {
    $isSignedIn = false;
    if (\Jadu\Symfony\DependencyInjection\ServiceLocator::has('security.token_storage')) {
        $user = \Jadu\Symfony\DependencyInjection\ServiceLocator::get('security.token_storage')->getToken()->getUser();

        if (is_object($user) && $user instanceof \Photon\CmsEngine\Model\Marketing\User\JaduUser) {
            $isSignedIn = true;
        }
    }
}

$contentWidgetContent = $outContent;
if ($isSignedIn) {
    $contentWidgetContent = $inContent;
}

$contentWidgetContent = str_replace('\"', '"', $contentWidgetContent);
$contentWidgetContent = str_replace('\\\'', '\'', $contentWidgetContent);
$contentWidgetTitle = str_replace('\"', '"', $contentWidgetTitle);
$input = Jadu\Service\Container::getInstance()->getInput(false);
$renderMediaPlayer = true;
if ($input->post('preview')) {
    $renderMediaPlayer = false;
}

if ($input->post('action') && $input->post('preview')) {
    $contentWidgetContent = str_replace('src="./images/', 'src="' . getCurrentProtocolSiteRootURL() . '/images/', $contentWidgetContent);
    // Editor class for control centre preview
    $editorClass = 'byEditor';
} else {
    // Editor class for front end
    $editorClass = 'editor';
}
?>
<?php
if ($contentWidgetTitle) {
?>
    <h2><?php echo encodeHtml($contentWidgetTitle); ?></h2>
<?php
}
?>
<?php if (processEditorContent($contentWidgetContent, $renderMediaPlayer)) {
    ?>
    <div class="widget_content byEditor by_editor <?php echo $editorClass; ?>"><?php echo processEditorContent($contentWidgetContent, $renderMediaPlayer); ?></div>
<?php
} ?>
