<?php
include_once 'JaduConstants.php';
$editor = $jadu->getEditor();
?>
<table class="form_table" id="lb_widget_content">
    <tbody>
        <tr>
            <td class="label_cell">Heading</td>
            <td class="data_cell"><input id="title" value="" size="12" class="field" type="text"></td>
        </tr>
        <tr>
            <td class="label_cell">Edit content</td>
            <td class="data_cell">
                <label for="in">
                    <input type="radio" id="in" name="editContent" value="in" checked> Signed in
                </label><br>
                <label for="out">
                    <input type="radio" id="out" name="editContent" value="out"> Signed out
                </label><br>
            </td>
        </tr>
        <tr>
            <td class="label_cell" colspan="2" style="text-align:left;">Content</td>
        </tr>
        <tr>
            <td class="data_cell" colspan="2">
                <?php echo $editor->getEditorMarkup('content', '', 'content', false); ?>
                <textarea name="inContent" id="inContent" style="display:none"></textarea>
                <textarea name="outContent" id="outContent" style="display:none"></textarea>
            </td>
        </tr>
    </tbody>
</table>
