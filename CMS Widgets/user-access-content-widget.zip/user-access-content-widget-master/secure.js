jQuery(function ($) {
    CKEDITOR.instances['content'].setData($('#' + $('#signedInOut .is-active a').data('set') + 'Content').val());

    $('#signedInOut a').on('click', function(event) {
        $('#signedInOut').find('.is-active').removeClass('is-active');
        $(event.target).closest('li').addClass('is-active');
        updateInOutContent();
    });

    CKEDITOR.instances['content'].on('change', function() {
        $('#' + $('#signedInOut .is-active a').data('set') + 'Content').val(CKEDITOR.instances['content'].getData());
    })

    function updateInOutContent()
    {
        CKEDITOR.instances['content'].setData($('#' + $('#signedInOut .is-active a').data('set') + 'Content').val());
    }
});
