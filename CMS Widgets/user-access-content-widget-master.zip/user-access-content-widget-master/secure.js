jQuery(function ($) {
    CKEDITOR.instances['content'].setData($('#' + $('input[name=editContent]:checked').val() + 'Content').val());

    $('input[type=radio][name=editContent]').change(function() {
        updateInOutContent();
    });

    CKEDITOR.instances['content'].on('change', function() {
        $('#' + $('input[name=editContent]:checked').val() + 'Content').val(CKEDITOR.instances['content'].getData());
    })

    function updateInOutContent()
    {
        CKEDITOR.instances['content'].setData($('#' + $('input[name=editContent]:checked').val() + 'Content').val());
    }
});
