<?php
require_once 'JaduConstants.php';

$contentWidgetTitle = '%TITLE%' === '%TITLE' . '%' ? '' : '%TITLE%';
$contentWidgetContent = '%CONTENT%' === '%CONTENT' . '%' ? '' : '%CONTENT%';
$documentAccessLevel = '%DOCUMENTACCESSLEVEL%' === '%DOCUMENTACCESSLEVEL' . '%' ? '' : '%DOCUMENTACCESSLEVEL%';

$contentWidgetContent = str_replace('\"', '"', $contentWidgetContent);
$contentWidgetContent = str_replace('\\\'', '\'', $contentWidgetContent);
$contentWidgetTitle = str_replace('\"', '"', $contentWidgetTitle);
$input = Jadu_Service_Container::getInstance()->getInput(false);

$user = Jadu_Service_User::getInstance();
if ($user->isSessionLoggedIn()) {
    $userAccessLevel = $user->getSessionUser()->accessLevel;
    if ($userAccessLevel >= $documentAccessLevel) {
        $renderMediaPlayer = true;
        if ($input->post('preview')) {
            $renderMediaPlayer = false;
        }

        if ($input->post('action') && $input->post('preview')) {
            $contentWidgetContent = str_replace('src="./images/', 'src="' . getCurrentProtocolSiteRootURL() . '/images/', $contentWidgetContent);
            // Editor class for control centre preview
            $editorClass = 'byEditor';
        } else {
            // Editor class for front end
            $editorClass = 'editor';
        }

        if ($contentWidgetTitle) {
?>
            <h2><?php echo encodeHtml($contentWidgetTitle); ?></h2>
<?php
        }
        if (processEditorContent($contentWidgetContent, $renderMediaPlayer)) {
?>
            <div class="widget_content byEditor by_editor <?php echo $editorClass; ?>"><?php echo processEditorContent($contentWidgetContent, $renderMediaPlayer); ?></div>
<?php
        }
    }
}
?>
