<?php
require_once 'JaduConstants.php';

$contentWidgetTitle = '%TITLE%' === '%TITLE' . '%' ? '' : '%TITLE%';
$contentWidgetContent = '%CONTENT%' === '%CONTENT' . '%' ? '' : '%CONTENT%';
$documentAccessLevel = '%DOCUMENTACCESSLEVEL%' === '%DOCUMENTACCESSLEVEL' . '%' ? '' : '%DOCUMENTACCESSLEVEL%';

$contentWidgetContent = str_replace('\"', '"', $contentWidgetContent);
$contentWidgetContent = str_replace('\\\'', '\'', $contentWidgetContent);
$contentWidgetTitle = str_replace('\"', '"', $contentWidgetTitle);
$input = Jadu\Service\Container::getInstance()->getInput(false);

if (!defined('PHOTON_ENABLED') || !PHOTON_ENABLED) {
    $user = Jadu\Service\Container::getInstance()->getJaduUser();
    $isSignedIn = $user->isSessionLoggedIn();
    $userAccessLevel = $user->getSessionUser()->accessLevel;
} else {
    $isSignedIn = false;
    if (\Jadu\Symfony\DependencyInjection\ServiceLocator::has('security.token_storage')) {
        $user = \Jadu\Symfony\DependencyInjection\ServiceLocator::get('security.token_storage')->getToken()->getUser();

        if (is_object($user) && $user instanceof \Photon\CmsEngine\Model\Marketing\User\JaduUser) {
            $isSignedIn = true;
            $userAccessLevel = $user->getAccessLevel();
        }
    }
}
if ($isSignedIn) {
    if ($userAccessLevel >= $documentAccessLevel) {
        $renderMediaPlayer = true;
        if ($input->post('preview')) {
            $renderMediaPlayer = false;
        }

        if ($input->post('action') && $input->post('preview')) {
            $contentWidgetContent = str_replace('src="./images/', 'src="' . getCurrentProtocolSiteRootURL() . '/images/', $contentWidgetContent);
            // Editor class for control centre preview
            $editorClass = 'byEditor';
        } else {
            // Editor class for front end
            $editorClass = 'editor';
        }

        if ($contentWidgetTitle) {
?>
            <h2><?php echo encodeHtml($contentWidgetTitle); ?></h2>
<?php
        }
        if (processEditorContent($contentWidgetContent, $renderMediaPlayer)) {
?>
            <div class="widget_content byEditor by_editor <?php echo $editorClass; ?>"><?php echo processEditorContent($contentWidgetContent, $renderMediaPlayer); ?></div>
<?php
        }
    }
}
?>
