<?php
include_once 'JaduConstants.php';
$editor = $jadu->getEditor();
?>
<table class="form_table" id="lb_widget_content">
    <tbody>
        <tr>
            <td class="label_cell">Heading</td>
            <td class="data_cell"><input id="title" value="" size="12" class="field" type="text"></td>
        </tr>
        <tr>
            <td class="label_cell">
                Date of change *
                <span class="help-block" id="valid-help">dd/mm/yyyy</span>
            </td>
            <td class="data_cell">
                <input type="text" id="date" class="field" required>
                <a href="#" onclick="return loadLightbox('calendar', 'lb2', 'target=date&mode=lb2');"><img src="/jadu/images/cal.gif" alt="Click Here to Pick up the date" border="0" height="16" width="16"></a>
                <p style="display:none" class="validationWarning"><strong>You must enter a valid date.</strong></p>
            </td>
        </tr>
        <tr>
            <td class="label_cell">
                Time of change *
                <span class="help-block" id="valid-help">hh:mm</span>
            </td>
            <td class="data_cell">
                <input type="time" id="time" class="field" value="00:00" style="width:80%;height: 20px;padding: 5px 12px;border: 1px solid #ccc;border-bottom: 1px solid #ccc;border-radius: 4px;box-sizing: content-box;font-size: 1em;font-family:'proxima_novalight','Helvetica Neue','Helvetica','Arial',sans-serif;vertical-align: middle;"required>
                <p style="display:none" class="validationWarning"><strong>You must enter a valid time.</strong></p>
            </td>
        </tr>
        <tr>
            <td class="data_cell" colspan="2" style="background-color:#fff">
                <nav class="nav-inline" id="beforeAfterContent">
                    <ul class="nav-inline__list">
                        <li class="nav-inline__item is-active">
                            <a class="nav-inline__link" href="#beforeContent" data-set="before">Before content</a>
                        </li>
                        <li class="nav-inline__item">
                            <a class="nav-inline__link" href="#afterContent" data-set="after">After content</a>
                        </li>
                    </ul>
                </nav>
                <textarea name="beforeContent" id="beforeContent" style="display:none"></textarea>
                <textarea name="afterContent" id="afterContent" style="display:none"></textarea>
                <?php echo $editor->getEditorMarkup('content', '', 'content', false); ?>
            </td>
        </tr>
    </tbody>
</table>
