jQuery(function ($) {
    CKEDITOR.instances['content'].setData($('#' + $('#beforeAfterContent .is-active a').data('set') + 'Content').val());

    $('#beforeAfterContent a').on('click', function(event) {
        $('#beforeAfterContent').find('.is-active').removeClass('is-active');
        $(event.target).closest('li').addClass('is-active');
        updateBeforeAfterContent();
    });

    CKEDITOR.instances['content'].on('change', function() {
        $('#' + $('#beforeAfterContent .is-active a').data('set') + 'Content').val(CKEDITOR.instances['content'].getData());
    })

    function updateBeforeAfterContent()
    {
        CKEDITOR.instances['content'].setData($('#' + $('#beforeAfterContent .is-active a').data('set') + 'Content').val());
    }

    let onSaveButton = document.querySelector('#saveWidgetProperty');
        let originalSaveHandler = onSaveButton.onclick;
        onSaveButton.onclick = null;
        onSaveButton.addEventListener('click', function(e) {
            if (validateFields()) {
                originalSaveHandler(e);
            }
        }.bind(this), false);

    function validateFields()
    {
        $('#lb_widget_content .warning').removeClass('warning');
        $('.validationWarning').hide();

        var errors = [];
        if (!/^\d{2}\/\d{2}\/\d{4}$/.test($('#date').val())) {
            $('#date').closest('.data_cell').addClass('warning').siblings().addClass('warning');
            $('#date').siblings('.validationWarning').show();
            errors.push('date');
        }

        if (!/^\d{2}:\d{2}$/.test($('#time').val())) {
            $('#time').closest('.data_cell').addClass('warning').siblings().addClass('warning');
            $('#time').siblings('.validationWarning').show();
            errors.push('time');
        }

        if (errors.length) {
            document.getElementById(errors[0]).scrollIntoView();
            return false;
        }

        return true;
    }
});
