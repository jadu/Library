<?php
require_once 'JaduConstants.php';

$contentWidgetTitle = '%TITLE%' === '%TITLE' . '%' ? '' : '%TITLE%';
$beforeContent = '%BEFORECONTENT%' === '%BEFORECONTENT' . '%' ? '' : '%BEFORECONTENT%';
$afterContent = '%AFTERCONTENT%' === '%AFTERCONTENT' . '%' ? '' : '%AFTERCONTENT%';
$changeDate = '%DATE%' === '%DATE' . '%' ? '' : '%DATE%';
$changeTime = '%TIME%' === '%TIME' . '%' ? '' : '%TIME%';

if (strtotime(str_replace('/', '-', $changeDate) . ' ' . $changeTime) < time()) {
    $contentWidgetContent = $afterContent;
} else {
    $contentWidgetContent = $beforeContent;
}

$contentWidgetContent = str_replace('\"', '"', $contentWidgetContent);
$contentWidgetContent = str_replace('\\\'', '\'', $contentWidgetContent);
$contentWidgetTitle = str_replace('\"', '"', $contentWidgetTitle);
$input = Jadu_Service_Container::getInstance()->getInput(false);
$renderMediaPlayer = true;
if ($input->post('preview')) {
    $renderMediaPlayer = false;
}

if ($input->post('action') && $input->post('preview')) {
    $contentWidgetContent = str_replace('src="./images/', 'src="' . getCurrentProtocolSiteRootURL() . '/images/', $contentWidgetContent);
    // Editor class for control centre preview
    $editorClass = 'byEditor';
} else {
    // Editor class for front end
    $editorClass = 'editor';
}
?>
<?php
if ($contentWidgetTitle) {
?>
    <h2><?php echo encodeHtml($contentWidgetTitle); ?></h2>
<?php
}
?>
<?php if (processEditorContent($contentWidgetContent, $renderMediaPlayer)) {
    ?>
    <div class="widget_content byEditor by_editor <?php echo $editorClass; ?>"><?php echo processEditorContent($contentWidgetContent, $renderMediaPlayer); ?></div>
<?php
} ?>
