<table class="form_table" id="lb_widget_content">
    <tbody>
    <tr>
        <td class="label_cell">Title</td>
        <td class="data_cell">
            <input type="text" id="nav_widget_title" size="12" class="field" value="" />
        </td>
    </tr>
    <tr>
        <td class="label_cell"></td>
        <td class="data_cell">
            <input type="button" value="Add Charity" class="btn btn--old-table" onclick="addWidgetLink();" />
        </td>
    </tr>
    <tr>
        <td colspan="2">
            <table class="list_table">
                <tbody id="nav_widget_links">
                </tbody>
            </table>
        </td>
    </tr>
    </tbody>
    <tfoot style="display:none;">
    <tr>
        <td class="label_cell">Charity</td>
        <td class="data_cell">
            <select onchange="selectCharity()" id="charities">
                <option value="redcross">Australian Red Cross</option>
                <option value="salvationarmy">The Salvation Army</option>
                <option value="wwf">WWF-Australia</option>
                <option value="custom">Custom...</option>
            </select>
        </td>
    </tr>
    <tr>
        <td class="label_cell">Title</td>
        <td class="data_cell">
            <input type="text" size="12" class="field" id="nav_link_title" value="" oninput="customCharity()" />
        </td>
    </tr>
    <tr>
        <td class="label_cell">Link</td>
        <td class="data_cell">
            <input type="text" size="12" class="field" id="nav_link" value="" oninput="customCharity()" />
        </td>
    </tr>
    <tr>
        <td class="label_cell">
            <input type="button" class="btn btn--danger" id="widgetLinkDelete" value="Delete Link" onclick="deleteWidgetLink()" />
        </td>
        <td class="data_cell">
            <input type="button" class="btn btn--primary" value="Save Link" onclick="saveWidgetLink();" />
        </td>
    </tr>
    </tfoot>
</table>
