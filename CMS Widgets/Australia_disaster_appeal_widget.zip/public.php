<?php
require_once 'websections/JaduHomepageWidgetSettings.php';
require_once 'ext/json.php';

$input = Jadu_Service_Container::getInstance()->getInput(false);

$preview = (isset($isPreviewLink) && $isPreviewLink && isset($allowPreview) && $allowPreview);

$allWidgetLinks = [];

if (isset($_POST['preview'])) {
    $newSettings = [];

    $j = 0;

    if (!empty($settings)) {
        foreach ($settings as $name => $value) {
            $newSettings[$j] = new stdClass();
            $newSettings[$j]->name = $name;
            $newSettings[$j]->value = $value;

            $newSettings[$j]->value = str_replace('_apos_', "'", $newSettings[$j]->value);
            $newSettings[$j]->value = str_replace('_amp_', '&', $newSettings[$j]->value);
            $newSettings[$j]->value = str_replace('_eq_', '=', $newSettings[$j]->value);
            $newSettings[$j]->value = str_replace('_hash_', '#', $newSettings[$j]->value);
            $newSettings[$j]->value = str_replace('_ques_', '?', $newSettings[$j]->value);
            $newSettings[$j]->value = str_replace('_perc_', '%', $newSettings[$j]->value);

            ++$j;
        }
    }

    $settings = $newSettings;
} else {
    if (isset($widget) && !is_array($widget)) {
        if (isset($_POST['homepageContent'])) {
            $settings = [];
            foreach ($widgetSettings[$widget->id] as $setting) {
                $newSetting = new WidgetSetting();
                $newSetting->name = $setting->name;
                $newSetting->value = $setting->value;

                $newSetting->value = str_replace('_apos_', "'", $newSetting->value);
                $newSetting->value = str_replace('_amp_', '&', $newSetting->value);
                $newSetting->value = str_replace('_eq_', '=', $newSetting->value);
                $newSetting->value = str_replace('_hash_', '#', $newSetting->value);
                $newSetting->value = str_replace('_ques_', '?', $newSetting->value);
                $newSetting->value = str_replace('_perc_', '%', $newSetting->value);

                $settings[] = $newSetting;
            }
        } elseif ((isset($_POST['action']) && 'getPreviews' == $_POST['action']) || $preview) {
            $settings = getAllSettingsForHomepageWidget($widget->id);
        } else {
            $settings = getAllSettingsForHomepageWidget($widget->id, true);
        }
    } else {
        if (isset($_POST['homepageContent'])) {
            $settings = [];
            foreach ($widgetSettings[$stack->id] as $setting) {
                $newSetting = new WidgetSetting();
                $newSetting->name = $setting->name;
                $newSetting->value = $setting->value;
                $settings[] = $newSetting;
            }
        } elseif (isset($_POST['getPreviews']) || $preview) {
            $settings = getAllSettingsForHomepageWidget($stack->id);
        } else {
            $settings = getAllSettingsForHomepageWidget($stack->id, true);
        }
    }
}

$tempLinks = [];
$tempTitles = [];
$nav_widget_title = '';

if (!empty($settings)) {
    foreach ($settings as $value) {
        if (preg_match('/link[0-9]+title/i', $value->name)) {
            $tempTitles[] = $value->value;
        }
        if (preg_match('/link[0-9]+url/i', $value->name)) {
            $tempLinks[] = $value->value;
        }
        if ('nav_widget_title' == $value->name) {
            $nav_widget_title = $value->value;
        }
    }
}

for ($i = 0; $i < sizeof($tempLinks); ++$i) {
    $allWidgetLinks[] = [$tempTitles[$i], $tempLinks[$i]];
}
?>

<div class="widget widget-navigation" aria-label="Australia Disaster Appeal Widget">
    <?php if ('' != $nav_widget_title): ?>
        <h2 class="widget__heading"><?php echo encodeHtml($nav_widget_title); ?></h2>
    <?php endif; ?>

    <?php if (!empty($allWidgetLinks)): ?>
        <ul class="list list--navigation">
        <?php foreach ($allWidgetLinks as $widgetLink):
            $link = ((0 !== strpos($widgetLink[1], 'http://') && 0 !== strpos($widgetLink[1], 'https://')) ? 'http://' : '') . encodeHtml($widgetLink[1]); ?>
            <li class="list__item">
                <a class="list__link" href="<?php echo $link; ?>">
                    <span class="list__link-text"><?php echo encodeHtml($widgetLink[0]); ?></span>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
    <?php endif; ?>
</div>
