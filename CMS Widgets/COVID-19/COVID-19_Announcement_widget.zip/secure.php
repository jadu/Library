<?php
    $fieldConfig = [
        [
            'type' => 'text',
            'label' => 'Title',
            'name' => 'name',
            'required' => true,
        ],
        [
            'type' => 'textarea',
            'label' => 'Summary',
            'name' => 'text',
            'required' => true,
        ],
        [
            'type' => 'date',
            'label' => 'Start date',
            'name' => 'datePosted',
            'required' => true,
            'comparisons' => [
                [
                    'rule' => '<=',
                    'target' => 'expires',
                    'emptyCompare' => false,
                    'failureMessage' => 'must be before end date'
                ]
            ],
        ],
        [
            'type' => 'date',
            'label' => 'End date',
            'name' => 'expires',
            'comparisons' => [
                [
                    'rule' => '>=',
                    'target' => 'datePosted',
                    'emptyCompare' => false,
                    'failureMessage' => 'must be after start date'
                ]
            ],
            'help' => 'Date in which the content expires or is no longer useful, if applicable.',
        ],
        [
            'type' => 'list',
            'label' => 'Announcement location(s)',
            'name' => 'announcementLocation',
            'itemName' => 'Location',
            'fieldConfig' => [
                [
                    'type' => 'select',
                    'label' => 'Type',
                    'name' => 'type',
                    'required' => true,
                    'options' => [
                        [
                            'label' => 'Select a type',
                            'value' => '',
                        ],
                        [
                            'label' => 'Civic Structure',
                            'value' => 'CivicStructure',
                        ],
                        [
                            'label' => 'Local Business',
                            'value' => 'LocalBusiness',
                        ],
                    ],
                    'help' => 'Type of the location (see: <a href="https://schema.org/announcementLocation" target="_blank">https://schema.org/announcementLocation</a>)'
                ],
                [
                    'type' => 'text',
                    'label' => 'Name',
                    'name' => 'name',
                    'required' => true,
                ],
                [
                    'type' => 'text',
                    'label' => 'Street Address',
                    'name' => 'streetAddress',
                ],
                [
                    'type' => 'text',
                    'label' => 'Region / County',
                    'name' => 'addressRegion',
                ],
                [
                    'type' => 'text',
                    'label' => 'Country',
                    'name' => 'addressCountry',
                ],
                [
                    'type' => 'text',
                    'label' => 'Postcode',
                    'name' => 'postalCode',
                ],
                [
                    'type' => 'url',
                    'label' => 'URL',
                    'name' => 'url',
                    'help' => 'URL for more information about the location, if applicable.'
                ]
            ],
            'help' => 'The specific location that is associated with the Announcement. For a larger geographic region, like a quarantine of an entire region, it\'s recommended to use affected regions',
        ],
        [
            'type' => 'list',
            'label' => 'Affected region(s)',
            'name' => 'spatialCoverage',
            'itemName' => 'Region',
            'fieldConfig' => [
                [
                    'type' => 'text',
                    'label' => 'Name',
                    'name' => 'name',
                    'required' => true,
                ]
            ],
            'help' => 'The geographic region(s) that are the focus of the special announcement, if applicable.',
        ],
        [
            'type' => 'url',
            'label' => 'Category',
            'name' => 'category',
            'help' => 'URL to describe the announcement (e.g. COVID-19 Wikipedia page: https://www.wikidata.org/wiki/Q81068910).'
        ],
        [
            'type' => 'url',
            'label' => 'Disease prevention information',
            'name' => 'diseasePreventionInfo',
            'help' => 'URL for information about disease prevention, if applicable.'
        ],
        [
            'type' => 'url',
            'label' => 'Disease spread statistics',
            'name' => 'diseaseSpreadStatistics',
            'help' => 'URL for statistical information about the disease spread, if applicable.'
        ],
        [
            'type' => 'url',
            'label' => 'Getting tested information',
            'name' => 'gettingTestedInfo',
            'help' => 'URL for information about the spread of a disease, if applicable.'
        ],
        [
            'type' => 'url',
            'label' => 'News updates and guidelines',
            'name' => 'newsUpdatesAndGuidelines',
            'help' => 'URL for any news updates and guidelines, if applicable.'
        ],
        [
            'type' => 'url',
            'label' => 'Public transport closures information',
            'name' => 'newsUpdatesAndGuidelines',
            'help' => 'URL for information about public transport closures, if applicable.'
        ],
        [
            'type' => 'url',
            'label' => 'Quarantine guidelines',
            'name' => 'quarantineGuidelines',
            'help' => 'URL for information about quarantine rules, if applicable.'
        ],
        [
            'type' => 'url',
            'label' => 'School closures information',
            'name' => 'schoolClosuresInfo',
            'help' => 'URL for information about school closures, if applicable.'
        ],
        [
            'type' => 'url',
            'label' => 'Travel bans',
            'name' => 'travelBans',
            'help' => 'URL for information about travel bans, if applicable.'
        ],
    ];
?>
<style type="text/css">
    #special-announcement-container {
        padding: 10px;
    }

    #special-announcement-container .modal__title {
        padding-bottom: 10px;
    }

    #special-announcement-container .loading-block {
        text-align: center;
    }

    #special-announcement-container .loading {
        display: block;
        margin: 0 auto;
    }

    #special-announcement-container .loading-block__message {
        display: block;
        margin-top: 12px;
    }

    .position-button + .position-button {
        margin-left: 5px !important;
    }

    .position-down {
        margin-left: 46px !important;
    }

    .position-down ~ .position-up {
        margin-left: 5px !important;
    }

    #add-announcement-form {
        padding: 10px !important;
    }

    #add-announcement-form .error-summary {
        background-color: #fff;
        border: 5px solid #c84d40;
        color: #3e3e3e;
        font-family: "proxima_nova_rgregular", "Helvetica Neue", "Helvetica", "Arial", sans-serif;
        margin-bottom: 20px;
        padding: 15px;
    }

    #add-announcement-form .error-summary .error-summary__title {
        font-weight: normal;
        line-height: 1em;
        margin: 0 0 1em;
        padding: 0;
        border: none;
    }

    #add-announcement-form .error-summary .error-summary__list {
        list-style: none;
        margin: 0;
        padding-left: 0;
    }

    #add-announcement-form .repeatable__list {
        background-color: #efefef;
    }
</style>
<div id="special-announcement-container" class="tab__content">
    <div id="root-container">
        <input type="hidden" id="special-announcements-fields" value="<?php echo htmlspecialchars(json_encode($fieldConfig)); ?>" />
        <div class="loading-block">
            <span class="loading loading--large"><i>Loading...</i></span>
            <span class="loading-block__message">Loading Announcements...</span>
        </div>
    </div>
</div>
