<?php

if (!empty($GLOBALS['preview_mode']) && isset($settings)) {
    foreach ($settings as $name => $value) {
        $settings[$name] = str_replace("\\'", "'", $value);
    }
} else {
    if (!isset($widget)) {
        return;
    }

    $settings = [];
    if (get_class($widget) === 'Photon\CmsEngine\Model\PublishingContent\Homepage\HomepageWidget') {
        foreach ($widget->getWidgetSettings() as $widgetSetting) {
            $settings[$widgetSetting->getName()] = $widgetSetting->getValue();
        }
    }

    if (get_class($widget) === 'WidgetToHomepage') {
        foreach ($widget->getWidgetSettings() as $widgetSetting) {
            $settings[$widgetSetting->name] = $widgetSetting->value;
        }
    }
}

if (!isset($settings['data'])) {
    return;
}

$announcements = json_decode($settings['data'], true);
$jsonData = [];

echo '<div class="special-announcement-widget">';
foreach ($announcements as $announcement) {
    $data = array_filter([
        '@context' => 'http://schema.org',
        '@type' => 'SpecialAnnouncement',
        'name' => isset($announcement['name']) ? $announcement['name'] : '',
        'text' => isset($announcement['text']) ? $announcement['text'] : '',
        'datePosted' => isset($announcement['datePosted']) ? $announcement['datePosted'] : '',
        'expires' => isset($announcement['expires']) ? $announcement['expires'] : '',
        'url' => isset($announcement['url']) ? $announcement['url'] : '',
        'category' => isset($announcement['category']) ? $announcement['category'] : '',
        'diseasePreventionInfo' => isset($announcement['diseasePreventionInfo']) ? $announcement['diseasePreventionInfo'] : '',
        'diseaseSpreadStatistics' => isset($announcement['diseaseSpreadStatistics']) ? $announcement['diseaseSpreadStatistics'] : '',
        'gettingTestedInfo' => isset($announcement['gettingTestedInfo']) ? $announcement['gettingTestedInfo'] : '',
        'newsUpdatesAndGuidelines' => isset($announcement['newsUpdatesAndGuidelines']) ? $announcement['newsUpdatesAndGuidelines'] : '',
        'quarantineGuidelines' => isset($announcement['quarantineGuidelines']) ? $announcement['quarantineGuidelines'] : '',
        'schoolClosuresInfo' => isset($announcement['schoolClosuresInfo']) ? $announcement['schoolClosuresInfo'] : '',
        'travelBans' => isset($announcement['travelBans']) ? $announcement['travelBans'] : '',
    ]);

    $announcementLocation = [];
    if (!empty($announcement['announcementLocation'])) {
        foreach ($announcement['announcementLocation'] as $location) {
            $postalAddress = array_filter([
                'streetAddress' => isset($location['streetAddress']) ? $location['streetAddress'] : '',
                'addressRegion' => isset($location['addressRegion']) ? $location['addressRegion'] : '',
                'addressCountry' => isset($location['addressCountry']) ? $location['addressCountry'] : '',
                'postalCode' => isset($location['postalCode']) ? $location['postalCode'] : '',
            ]);

            $locationData = [
                '@type' => isset($location['type']) ? $location['type'] : '',
                'name' => isset($location['name']) ? $location['name'] : '',
                'url' => isset($location['url']) ? $location['url'] : '',
            ];

            if (!empty($postalAddress)) {
                $locationData['address'] = array_merge([
                    '@type' => 'PostalAddress',
                ], $postalAddress);
            }

            $announcementLocation[] = array_filter($locationData);
        }
    }

    if (!empty($announcementLocation)) {
        $data['announcementLocation'] = $announcementLocation;
    }

    $spatialCoverage = [];
    if (!empty($announcement['spatialCoverage'])) {
        foreach ($announcement['spatialCoverage'] as $coverage) {
            $spatialCoverage[] = array_filter([
                '@type' => 'AdministrativeArea',
                'name' => isset($coverage['name']) ? $coverage['name'] : '',
            ]);
        }
    }

    if (!empty($spatialCoverage)) {
        $data['spatialCoverage'] = $spatialCoverage;
    }

    $datePosted = false;
    if (!empty($data['datePosted'])) {
        $datePosted = DateTime::createFromFormat('Y-m-d', $data['datePosted']);
    }

    $dateExpires = false;
    if (!empty($data['expires'])) {
        $dateExpires = DateTime::createFromFormat('Y-m-d', $data['expires']);
    }

    $currentDate = new Datetime();

    $visible = isset($announcement['visible']) ? boolval($announcement['visible']) : true;

    // check if the announcement is 'current', only displaying is so
    if (
        $visible
        && (empty($datePosted) || $currentDate >= $datePosted)
        && (empty($dateExpires) || $currentDate <= $dateExpires)
    ) {
        // output the announcement
        echo '<div class="special-announcement">';
        if (!empty($data['category'])) {
            echo '<h2><a href="' . $data['category']  . '">' . $data['name'] . '</a></h2>';
        } else {
            echo '<h2>' . $data['name'] . '</h2>';
        }
        echo '<p>' . $data['text'] . '</p>';

        if (!empty($data['diseasePreventionInfo'])) {
            echo '<p><a href="' . $data['diseasePreventionInfo']  . '">Disease prevention information</a></p>';
        }

        if (!empty($data['diseaseSpreadStatistics'])) {
            echo '<p><a href="' . $data['diseaseSpreadStatistics']  . '">Disease spread statistics</a></p>';
        }

        if (!empty($data['gettingTestedInfo'])) {
            echo '<p><a href="' . $data['gettingTestedInfo']  . '">Getting tested information</a></p>';
        }

        if (!empty($data['newsUpdatesAndGuidelines'])) {
            echo '<p><a href="' . $data['newsUpdatesAndGuidelines']  . '">News updates and guidelines</a></p>';
        }

        if (!empty($data['quarantineGuidelines'])) {
            echo '<p><a href="' . $data['quarantineGuidelines']  . '">Quarantine guidelines</a></p>';
        }

        if (!empty($data['schoolClosuresInfo'])) {
            echo '<p><a href="' . $data['schoolClosuresInfo']  . '">School closures information</a></p>';
        }

        if (!empty($data['travelBans'])) {
            echo '<p><a href="' . $data['travelBans']  . '">Travel bans</a></p>';
        }

        if (!empty($datePosted)) {
            echo '<p>Published: <time datetime="' . $data['datePosted'] . '"></time>' . $datePosted->format('j F Y') . '</p>';
        }

        if (!empty($dateExpires)) {
            echo '<p>Expires: <time datetime="' . $data['expires'] . '"></time>' . $dateExpires->format('j F Y') . '</p>';
        }

        echo '</div>';
    }

    // add announcement data to array, for json-ld output
    $jsonData[] = array_filter($data);
}

if (!empty($GLOBALS['preview_mode'])) {
    echo '<h2>Structured data markup preview:</h2>';
    echo '<pre>';
    echo json_encode(array_filter($jsonData), JSON_PRETTY_PRINT);
    echo '</pre>';
} else {
    echo '<scr' . 'ipt type="application/ld+json">';
    echo json_encode(array_filter($jsonData));
    echo '</scr' . 'ipt>';
}

echo '</div>';

?>
