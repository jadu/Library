(function () {
    let SpecialAnnouncementWidget = (function (){
        function SpecialAnnouncementWidget(container, options) {
            options = Object.assign({
                fieldConfig: [],
                data: [],
                activePage: 'list',
                pageConfig: {},
            }, options);

            this.container = container;
            this.fieldConfig = options.fieldConfig;
            this.data = options.data;
            this.pageConfig = options.pageConfig;

            this.setActivePage(options.activePage);
        }

        SpecialAnnouncementWidget.prototype.setActivePage = function(pageName, options) {
            options = Object.assign(
                {
                    fieldConfig: this.fieldConfig,
                    data: this.data,
                },
                Object.assign(this.pageConfig[pageName] ? this.pageConfig[pageName] : {}, options)
            );

            let page = null;
            switch (pageName) {
                case 'list':
                    page = new ListPage(
                        Object.assign(options, {
                            onNewHandler: function () {
                                this.setActivePage('item', {
                                    id: null,
                                });
                            }.bind(this),
                            onMoveHandler: function (id, position) {
                                this.moveItem(id, position);
                                this.setActivePage('list');
                            }.bind(this),
                            onEditHandler: function (id) {
                                this.setActivePage('item', {
                                    id: id,
                                })
                            }.bind(this),
                            onDeleteHandler: function (id) {
                                this.deleteAnnouncement(id);
                                this.setActivePage('list');
                            }.bind(this),
                        })
                    );
                    break;
                case 'item':
                    let itemData = {};
                    if (options.id) {
                        itemData = this.data[this.findDataIndexById(options.id)];
                    }

                    page = new ItemPage(
                        Object.assign(options, {
                            data: itemData,
                            onSaveHandler: function (data) {
                                if (options.id) {
                                    data.id = options.id;
                                    this.data[this.findDataIndexById(options.id)] = data;
                                } else {
                                    data.id = this.genUid();
                                    this.data.unshift(data);
                                }

                                this.setActivePage('list');
                            }.bind(this),
                            onCloseHandler: function () {
                                this.setActivePage('list');
                            }.bind(this),
                        })
                    );
                    break;
            }

            if (page === null) {
                return;
            }

            let content = page.renderPage();
            this.container.innerText = '';
            this.container.appendChild(content);
            content.scrollIntoView();
            content.focus();
        };

        SpecialAnnouncementWidget.prototype.getData = function() {
            return this.data;
        };

        SpecialAnnouncementWidget.prototype.moveItem = function(id, direction) {
            let index = this.findDataIndexById(id);
            if (index === -1) {
                return;
            }

            if (direction === 'up') {
                this.moveArrayItem(this.data, index, -1);
            }

            if (direction === 'down') {
                this.moveArrayItem(this.data, index, 1);
            }
        };

        SpecialAnnouncementWidget.prototype.moveArrayItem = function(array, index, delta) {
            let newIndex = index + delta;
            if (newIndex < 0 || newIndex === array.length) {
                return;
            }

            let indexes = [index, newIndex].sort();
            array.splice(indexes[0], 2, array[indexes[1]], array[indexes[0]]);
        };

        SpecialAnnouncementWidget.prototype.findDataIndexById = function(id) {
            if (typeof id === 'undefined') {
                return -1;
            }

            return this.data.findIndex(function (element) {
                return element.id === id;
            });
        };

        SpecialAnnouncementWidget.prototype.deleteAnnouncement = function(id) {
            if (confirm('Are you sure you want to delete this Announcement?')) {
                let index = this.findDataIndexById(id);
                if (index > -1) {
                    this.data.splice(index, 1);
                }
            }
        };

        SpecialAnnouncementWidget.prototype.genUid = function() {
            return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
        };

        SpecialAnnouncementWidget.prototype.onSave = function() {
            this.container.innerHTML = '';
            window.widgetItems[window.activeWidget].settings = {
                data: Object.toJSON(this.data),
                fields: settings.fields
            };
        };

        return SpecialAnnouncementWidget;
    })();


    let ListPage = (function () {
        function ListPage(options) {
            options = Object.assign({
                fieldConfig: [],
                data: {},
                newButtonAlignment: 'center',
                newButtonClassName: '',
                className: '',
                onNewHandler: function() {},
                onMoveHandler: function(id, direction) {},
                onEditHandler: function(id) {},
                onDeleteHandler: function(id) {},
            }, options);

            this.fieldConfig = options.fieldConfig;
            this.data = options.data;
            this.pageTitle = options.pageTitle;
            this.itemName = options.itemName;
            this.className = options.className;
            this.newButtonAlignment = options.newButtonAlignment;
            this.newButtonClassName = options.newButtonClassName;
            this.onNewHandler = options.onNewHandler;
            this.onMoveHandler = options.onMoveHandler;
            this.onEditHandler = options.onEditHandler;
            this.onDeleteHandler = options.onDeleteHandler;
            this.columns = [
                'Name',
                'Positions',
                'Actions',
            ];
        }

        ListPage.prototype.renderPage = function() {
            let containerElement = document.createElement('div');

            if (this.pageTitle) {
                let titleElement = document.createElement('h5');
                titleElement.className = 'modal__title';
                titleElement.innerText = this.pageTitle;
                containerElement.appendChild(titleElement);
            }

            containerElement.appendChild(this.renderTable());

            let buttonWrapper = document.createElement('div');
            buttonWrapper.style.textAlign = this.newButtonAlignment;
            let newAnnouncementButton = FieldFactory.createButton({
                value: 'Add new' + (this.itemName ? ' ' + this.itemName : ''),
                className: this.newButtonClassName,
            });
            newAnnouncementButton.addEventListener('click', function() {
                this.onNewHandler();
            }.bind(this));

            buttonWrapper.appendChild(newAnnouncementButton);
            containerElement.appendChild(buttonWrapper);

            return containerElement;
        };

        ListPage.prototype.renderTable = function() {
            let tableElement = document.createElement('table');
            tableElement.id = 'announcement-list';
            tableElement.className = 'table table--full';

            let tableHeaderElement = document.createElement('thead');
            tableElement.appendChild(tableHeaderElement);

            let tableHeaderRowElement = document.createElement('tr');
            tableHeaderElement.appendChild(tableHeaderRowElement);
            this.columns.forEach(function (column) {
                let columnElement = document.createElement('th');
                columnElement.innerText = column;
                tableHeaderRowElement.appendChild(columnElement);
            });

            let tableBodyElement = document.createElement('tbody');
            tableElement.appendChild(tableBodyElement);
            if (this.data.length === 0) {
                let row = document.createElement('tr');
                let data = document.createElement('td');
                data.className = 'no-results';
                data.colSpan = 3;
                row.appendChild(data);

                let message = document.createElement('dev');
                message.className = 'no-results__message';
                message.innerText = 'There are currently no ' + (this.pageTitle ? this.pageTitle : 'items');
                data.appendChild(message);

                tableBodyElement.appendChild(row);

                return tableElement;
            }

            this.data.forEach(function (item, index) {
                let row = document.createElement('tr');

                // name column
                let name = document.createElement('td');
                name.innerText = item.name ? item.name : 'Item ' + (index + 1);
                row.appendChild(name);


                // position column
                let position = document.createElement('td');
                if (index > 0) {
                    let moveUpButton = FieldFactory.createButton({
                        className: 'position-button position-up',
                        icon: 'icon-arrow-up',
                        value: 'Move up'
                    });
                    moveUpButton.addEventListener('click', function() {
                        this.onMoveHandler(item.id, 'up');
                    }.bind(this));
                    position.appendChild(moveUpButton);
                }

                if (index < (this.data.length - 1)) {
                    let moveDownButton = FieldFactory.createButton( {
                        className: 'position-button position-down',
                        icon: 'icon-arrow-down',
                        value: 'Move down'
                    });
                    moveDownButton.addEventListener('click', function() {
                        this.onMoveHandler(item.id, 'down');
                    }.bind(this));
                    position.appendChild(moveDownButton);
                }

                row.appendChild(position);

                // actions column
                let actions = document.createElement('td');

                let editButton = FieldFactory.createButton({
                    value: 'Edit'
                });
                editButton.addEventListener('click', function() {
                    this.onEditHandler(item.id);
                }.bind(this), false);
                actions.appendChild(editButton);

                let deleteButton = FieldFactory.createButton({
                    value: 'Delete'
                });
                deleteButton.style.marginLeft = '5px';
                deleteButton.addEventListener('click', function() {
                    this.onDeleteHandler(item.id);
                }.bind(this), false);
                actions.appendChild(deleteButton);

                row.appendChild(actions);

                tableBodyElement.appendChild(row);
            }.bind(this));

            return tableElement;
        };

        return ListPage;
    })();

    let ItemPage = (function () {
        function ItemPage(options) {
            options = Object.assign({
                fieldConfig: [],
                data: {},
                className: '',
                onSaveHandler: function(data) {},
                onCloseHandler: function() {},
            }, options);

            this.fieldConfig = options.fieldConfig;
            this.data = options.data;
            this.pageTitle = Object.keys(this.data).length
                ? 'Edit' + (options.itemName ? ' ' + options.itemName : '')
                : 'Add' + (options.itemName ? ' ' + options.itemName : '');
            this.className = options.className;
            this.onSaveHandler = options.onSaveHandler;
            this.onCloseHandler = options.onCloseHandler;

            this.fields = [];

            this.containerElement = null;
            this.errorSummaryElement = null;

            this.fieldConfig.forEach(function (config) {
                let field = FieldFactory.createField(config.type, Object.assign(config, {
                    value: typeof this.data[config.name] !== 'undefined' ? this.data[config.name] : '',
                }));
                if (field === null) {
                    return;
                }

                this.fields[config.name] = field;
            }.bind(this));
        }
        ItemPage.prototype.onSave = function() {
            let errors = this.validate();
            if (Object.keys(errors).length) {
                return;
            }

            this.onSaveHandler(this.getData());
        };
        ItemPage.prototype.onCancel = function() {
            this.onCloseHandler();
        };
        ItemPage.prototype.getData = function() {
            let data = {};
            Object.keys(this.fields).forEach(function (key) {
                let field = this.fields[key];

                data[key] = field.getValue();
            }.bind(this));

            return data;
        };
        ItemPage.prototype.validate = function() {
            let data = this.getData();

            let errors = [];
            Object.keys(this.fields).forEach(function (key) {
                let field = this.fields[key];

                let validationErrors = field.validate(data);
                if (validationErrors.length) {
                    errors[key] = validationErrors;
                }
            }.bind(this));

            if (Object.keys(errors).length) {
                if (this.errorSummaryElement !== null) {
                    this.errorSummaryElement.parentNode.removeChild(this.errorSummaryElement);
                }

                this.errorSummaryElement = ItemPage.renderErrorSummary(errors);
                this.containerElement.insertBefore(this.errorSummaryElement, this.containerElement.childNodes[0]);
                this.errorSummaryElement.focus();
            }

            return errors;
        };
        ItemPage.prototype.renderPage = function() {
            this.containerElement = document.createElement('div');
            this.containerElement.id = 'add-announcement-form';
            this.containerElement.className= this.className;

            if (this.pageTitle) {
                let titleElement = document.createElement('h5');
                titleElement.className = 'modal__title';
                titleElement.innerText = this.pageTitle;
                this.containerElement.appendChild(titleElement);
            }

            // form elements
            Object.keys(this.fields).forEach(function (key) {
                let field = this.fields[key];

                this.containerElement.appendChild(field.render());
            }.bind(this));

            // control buttons
            let saveButton = FieldFactory.createButton({
                name: 'save-announcement',
                className: 'btn--primary',
                value: 'Save',
            });
            saveButton.addEventListener('click', function() {
                this.onSave();
            }.bind(this));

            let cancelButton = FieldFactory.createButton({
                id: 'cancel-announcement',
                className: 'btn--naked',
                value: 'Cancel',
            });
            cancelButton.style.marginLeft = '5px';
            cancelButton.addEventListener('click', function() {
                this.onCloseHandler();
            }.bind(this));

            let groupElement = document.createElement('div');
            groupElement.className = 'form__actions';
            groupElement.appendChild(saveButton);
            groupElement.appendChild(cancelButton);
            this.containerElement.appendChild(groupElement);

            return this.containerElement;
        };
        ItemPage.renderErrorSummary = function(errors) {
            let element = document.createElement('section');
            element.className = 'error-summary';
            element.setAttribute('aria-labelledby', 'error-summary-title');
            element.setAttribute('data-error-summary', 'true');
            element.tabIndex = -1;

            let heading = document.createElement('h2');
            heading.className = 'error-summary__title';
            heading.id = 'error-summary-title';
            heading.innerText = 'There is a problem';
            element.appendChild(heading);

            let list = document.createElement('ul');
            list.className = 'error-summary__list';
            element.appendChild(list);

            Object.keys(errors).forEach(function (element) {
                let error = errors[element];

                let errorItem = document.createElement('li');
                errorItem.className = 'error-summary__list-item';
                errorItem.innerText = error;
                list.appendChild(errorItem);
            });

            return element;
        };

        return ItemPage;
    })();

    let FieldFactory = (function () {
        function FieldFactory() {}
        FieldFactory.createField = function(field, options) {
            switch (field) {
                case 'text':
                    return new TextField(options);
                case 'textarea':
                    return new TextAreaField(options);
                case 'date':
                    return new DateField(options);
                case 'url':
                    return new UrlField(options);
                case 'select':
                    return new SelectField(options);
                case 'list':
                    return new ListField(options);
                case 'toggle':
                    return new ToggleField(options);
                default:
                    return null;
            }
        };
        FieldFactory.createButton = function(options) {
            let element = document.createElement('button');
            element.className = 'btn ' + (options.className || '');
            element.innerText = options.value;
            if (options.icon) {
                element.innerText = '';

                let icon = document.createElement('i');
                icon.className = options.icon;

                let span = document.createElement('span');
                span.className = 'hide';
                span.innerText = options.value;
                icon.appendChild(span);
                element.appendChild(icon);
            }

            return element;
        };

        function Field(options) {
            options = Object.assign({
                value: '',
                help: '',
            }, options);

            this.name = options.name;
            this.label = options.label;
            this.help = options.help;
            this.value = options.value;
            this.className = 'form__control ' + (options.className ? options.className : '');
            this.required = (options.required ? options.required : false);
            this.comparisons = options.comparisons ? options.comparisons : [];
            this.type = null;
            this.groupElement = null;
            this.labelElement = null;
            this.controlsElement = null;
            this.inputElement = null;
            this.errorElement = null;
            this.helpElement = null;
        }
        Field.prototype.getValue = function() {
            if (this.inputElement === null) {
                return '';
            }

            return this.inputElement.value;
        };
        Field.prototype.removeErrorMessage = function() {
            if (this.errorElement !== null) {
                this.errorElement.parentNode.removeChild(this.errorElement);
                this.errorElement = null;
            }

            this.groupElement.className = this.groupElement.className.replace('has-error', '');
        };
        Field.prototype.displayErrorMessage = function(error) {
            this.removeErrorMessage();

            this.groupElement.className = this.groupElement.className += ' has-error';
            this.errorElement = document.createElement('span');
            this.errorElement.className = 'help-block is-error';

            let icon = document.createElement('i');
            icon.className = 'icon-warning-sign';

            this.errorElement.appendChild(icon);
            this.errorElement.innerHTML += ' ' + error;

            if (this.helpElement !== null) {
                this.controlsElement.insertBefore(this.errorElement, this.helpElement);
            } else {
                this.controlsElement.appendChild(this.errorElement);
            }
        };
        Field.prototype.validate = function(data) {
            let value = this.getValue();
            if (this.required && value === '') {
                this.displayErrorMessage('Must not be empty');

                return [this.label + ' must not be empty'];
            }

            let comparisonMessage = this.validateComparisons(data);
            if (comparisonMessage !== null) {
                this.displayErrorMessage(comparisonMessage.charAt(0).toUpperCase() + comparisonMessage.slice(1));

                return [this.label + ' ' + comparisonMessage];
            }

            this.removeErrorMessage();
            return [];
        };
        Field.prototype.validateComparisons = function(data) {
            let failure = null;
            this.comparisons.forEach(function (comparisonRule) {
                failure = this.validateComparison(comparisonRule, data);
            }.bind(this));

            return failure;
        };
        Field.prototype.validateComparison = function(comparisonRule, data) {
            let rule = comparisonRule.rule;
            let target = comparisonRule.target;
            let emptyCompare = comparisonRule.emptyCompare ? comparisonRule.emptyCompare : false;
            let failureMessage = comparisonRule.failureMessage;

            let sourceData = this.getValue();
            let targetData = data[target] ? data[target] : '';
            if (!emptyCompare && (sourceData === '' || targetData === '')) {
                return null;
            }

            if (typeof Field.comparisonTable[rule] === 'undefined' || Field.comparisonTable[rule](sourceData, targetData)) {
                return null;
            }

            return failureMessage;
        };
        Field.prototype.render = function() {
            this.groupElement = document.createElement('div');
            this.groupElement.className = 'form__group';

            this.labelElement = document.createElement('span');
            this.labelElement.className = 'control__label';
            this.labelElement.innerText = this.label + (this.required ? '*' : '');
            this.groupElement.appendChild(this.labelElement);

            this.controlsElement = document.createElement('span');
            this.controlsElement.className = 'controls';
            this.groupElement.appendChild(this.controlsElement);

            if (this.inputElement) {
                this.controlsElement.appendChild(this.inputElement);
            }

            if (this.help !== '') {
                this.helpElement = document.createElement('span');
                this.helpElement.className = 'help-block';
                this.helpElement.innerHTML += this.help;
                this.controlsElement.appendChild(this.helpElement);
            }

            return this.groupElement;
        };
        Field.comparisonTable = {
            '>': function (a, b) { return a > b; },
            '<': function (a, b) { return a < b; },
            '>=': function (a, b) { return a >= b; },
            '<=': function (a, b) { return a <= b; },
            '==': function (a, b) { return a == b; },
            '!=': function (a, b) { return a != b; },
        };

        function TextField(options) {
            Field.call(this, options);

            this.type = 'text';
        }
        TextField.prototype = Object.create(Field.prototype);
        TextField.prototype.constructor = Field;
        TextField.prototype.render = function() {
            let element = document.createElement('input');
            element.type = 'text';
            element.className = this.className;
            element.value = this.value;

            this.inputElement = element;
            return Field.prototype.render.call(this);
        };

        function TextAreaField(options) {
            Field.call(this, options);

            this.className = 'form__control textarea' + (options.className ? options.className : '');
            this.type = 'textarea';
        }
        TextAreaField.prototype = Object.create(Field.prototype);
        TextAreaField.prototype.constructor = TextAreaField;
        TextAreaField.prototype.render = function() {
            let element = document.createElement('textarea');
            element.type = 'textarea';
            element.className = this.className;
            element.value = this.value;

            this.inputElement = element;
            return Field.prototype.render.call(this);
        };

        function DateField(options) {
            Field.call(this, options);

            this.type = 'date';
        }
        DateField.prototype = Object.create(Field.prototype);
        DateField.prototype.constructor = DateField;
        DateField.prototype.render = function() {
            let element = document.createElement('input');
            element.type = 'date';
            element.className = this.className;
            element.value = this.value;

            this.inputElement = element;
            return Field.prototype.render.call(this);
        };

        function UrlField(options) {
            Field.call(this, options);

            this.type = 'url';
        }
        UrlField.prototype = Object.create(Field.prototype);
        UrlField.prototype.constructor = Field;
        UrlField.prototype.validate = function() {
            let valid = Field.prototype.validate.call(this);
            if (valid.length) {
                return valid;
            }

            let value = this.getValue();
            if (value  !== '') {
                let regexp =  /^(?:(?:https?|ftp):\/\/)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:\/\S*)?$/;
                if (!regexp.test(value)) {
                    this.displayErrorMessage('Must be a valid URL');

                    return [this.label + ' must be a valid URL'];
                }
            }

            this.removeErrorMessage();
            return true;
        };
        UrlField.prototype.render = function() {
            let element = document.createElement('input');
            element.type = 'text';
            element.className = this.className;
            element.value = this.value;

            this.inputElement = element;
            return Field.prototype.render.call(this);
        };

        function SelectField(options) {
            Field.call(this, options);

            this.className = 'form__control select' + (options.className ? options.className : '');
            this.options = options.options ? options.options : [];
            this.type = 'select';
        }
        SelectField.prototype = Object.create(Field.prototype);
        SelectField.prototype.constructor = DateField;
        SelectField.prototype.render = function() {
            let element = document.createElement('select');
            element.className = this.className;
            element.value = this.value;

            this.options.forEach(function (optionConfig) {
                let option = document.createElement('option');
                option.value = optionConfig.value;
                option.innerText = optionConfig.label;
                if (option.value === this.value) {
                    option.selected = true;
                }

                element.appendChild(option);
            }.bind(this));

            this.inputElement = element;
            return Field.prototype.render.call(this);
        };

        function ListField(options) {
            Field.call(this, options);

            this.value = options.value !== '' ? options.value : [],
            this.fieldConfig = options.fieldConfig ? options.fieldConfig : [];
            this.pageTitle = options.pageTitle;
            this.itemName = options.itemName;
            this.type = 'list';
            this.listWidget = null;
        }
        ListField.prototype = Object.create(Field.prototype);
        ListField.prototype.constructor = Field;
        ListField.prototype.render = function() {
            let element = document.createElement('div');
            this.listWidget = new SpecialAnnouncementWidget(element, {
                fieldConfig: this.fieldConfig,
                data: this.value,
                pageConfig: {
                    list: {
                        pageTitle: this.pageTitle,
                        itemName: this.itemName,
                        newButtonAlignment: 'left',
                    },
                    item: {
                        pageTitle: this.pageTitle,
                        itemName: this.itemName,
                        className: 'repeatable__list',
                    }
                },
            });

            this.inputElement = element;
            return Field.prototype.render.call(this);
        };
        ListField.prototype.getValue = function() {
            if (this.listWidget === null) {
                return [];
            }

            return this.listWidget.getData();
        };

        function ToggleField(options) {
            Field.call(this, options);

            this.className = 'form__control toggle-switch' + (options.className ? options.className : '');
            this.options = options.options ? options.options : [];
            this.type = 'toggle';
        }
        ToggleField.prototype = Object.create(Field.prototype);
        ToggleField.prototype.constructor = Field;
        ToggleField.prototype.render = function() {
            Field.prototype.render.call(this);

            let labelWrapperElement = document.createElement('label');
            labelWrapperElement.className = 'toggle-switch-wrapper-label';
            while (this.groupElement.childNodes.length > 0) {
                labelWrapperElement.appendChild(this.groupElement.childNodes[0]);
            }

            this.groupElement.appendChild(labelWrapperElement);

            this.inputElement = document.createElement('input');
            this.inputElement.className = this.className;
            this.inputElement.checked = (this.value == true);
            this.inputElement.type = 'checkbox';

            let spanElement = document.createElement('span');
            spanElement.className = 'toggle-switch-label';

            this.controlsElement.insertBefore(spanElement, this.controlsElement.childNodes[0]);
            this.controlsElement.insertBefore(this.inputElement, this.controlsElement.childNodes[0]);

            return this.groupElement
        };
        ToggleField.prototype.getValue = function() {
            return (this.inputElement.checked == true);
        };

        return FieldFactory;
    })();

    (function () {
        function loadFieldConfig() {
            let fieldsInput = document.querySelector('#special-announcements-fields');
            let fields = fieldsInput.value;
            if (!fields) {
                return;
            }

            if (typeof fields === 'string') {
                fields = JSON.parse(fields);
            }

            return fields;
        }

        function loadData() {
            let settings = (window.widgetItems[window.activeWidget || 0] || {}).settings;
            if (!settings) {
                return;
            }

            let data = typeof settings.data !== 'undefined' ? settings.data : [];
            if (typeof data === 'string') {
                data = JSON.parse(data);
            }

            return data;
        }

        let widget = new SpecialAnnouncementWidget(document.querySelector('#root-container'), {
            fieldConfig: loadFieldConfig(),
            data: loadData(),
            pageConfig: {
                list: {
                    pageTitle: 'Announcements',
                    itemName: 'Announcement',
                    newButtonClassName: 'btn--primary',
                },
                item: {
                    pageTitle: 'Announcements',
                    itemName: 'Announcement',
                }
            },
        });


        let onSaveButton = document.querySelector('#saveWidgetProperty');
        let originalSaveHandler = onSaveButton.onclick;
        onSaveButton.onclick = null;
        onSaveButton.addEventListener('click', function(e) {
            document.querySelector('#root-container').innerHTML = '';
            window.widgetItems[window.activeWidget].settings = {
                data: Object.toJSON(widget.getData()),
            };
            originalSaveHandler(e);
        }.bind(this), false);
    })();
})();
